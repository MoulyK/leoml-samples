sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";
var count = 1;
	return Controller.extend("demo-image-classify.controller.View1", {

		classify: function(e) {
			var fU = this.getView().byId("idfileUploader");
			var domRef = fU.getFocusDomRef();
			var file = domRef.files[0];
			var reader = new FileReader();
			var t = this;
			reader.onload = function(e) {
				var holder = t.byId("holder");
				var oImage = new sap.ui.commons.Image("i"+count);
				oImage.setSrc(e.target.result);
				oImage.setAlt("alternative image text for image");
				oImage.placeAt(holder.getDomRef());
			};
			reader.readAsDataURL(file);
			var response;
			var predictUrl = "https://sandbox.api.sap.com/ml/imageclassifier/inference_sync";
			var url = predictUrl;
			var form = new FormData();
			form.append("files", file);
			$.ajax({
				method: "POST",
				type: "POST",
				url: url,
				processData: false,
				contentType: false,
				mimeType: "multipart/form-data",
				headers: {
					"apikey": "<<< YOUR API KEY GOES HERE >>>",
					"accept": "application/json"
				},
				data: form,
				success: function(result, textStatus, jqXHR) {
					var obj = JSON.parse(result);
					var mlpredictions = obj['predictions'][0];
					var toplabel = mlpredictions['results'][0];
					var elresponse = t.byId("response");
					var olabel = new sap.ui.commons.Label("l"+count);
					olabel.setText(toplabel.label);
					olabel.setTextAlign("Center");
					olabel.setWidth("200px");
					olabel.setDesign(sap.ui.commons.LabelDesign.Bold);
					olabel.placeAt(elresponse.getDomRef());
					count++;
				},
				error: function(jqXHR, textStatus, error) {
					console.log("Error sending request to server ");
				},
				complete: function(jqXHR, textStatus) {}

			});
		}

	});
});