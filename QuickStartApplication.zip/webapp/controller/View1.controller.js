sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel"
], function(Controller, JSONModel) {
	"use strict";
	jQuery.sap.require("jquery.sap.storage");
	var oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
	return Controller.extend("QuickStartApplication.controller.View1", {
		onInit: function() {
			var that = this;
			that.refreshAccessToken();
			var model = new JSONModel();
			this.getView().setModel(model);
		},
		refreshAccessToken: function() {
			var url = "https://ml-test.apimanagement.hana.ondemand.com/sti/standalone/oauth/generateToken";
			var auth = "Basic " + btoa("nGr8LLOz9wdwxzZwmxV4zuLfKCt325HM" + ":" + "lk5vfWR8nyVdY75h");
			oStorage.clear();
			$.ajax({
				type: "POST",
				url: url,
				headers: {
					"Authorization": auth,
					"Content-Type": "application/x-www-form-urlencoded"
				},
				data: {
					"grant_type": "client_credentials"
				},
				success: function(data, textStatus, jqXHR) {
					if (data.access_token) {
						oStorage.put("/AccessToken", data.access_token);
					}
				},
				error: function(jqXHR, textStatus, error) {
					alert("Error occured, please refresh the application");
				}
			});
		},
		onAfterRendering: function() {
			document.getElementById("sap-ui-static").style.display = 'none';
		},
		getKeywordsUsed: function(response) {
			var keywordsResponse = response,
				keywords = [],
				tokenFields = [];

			for (var i = 0; i < keywordsResponse.length; i++) {
				tokenFields = keywordsResponse[i].token_values;
				for (var j = 0; j < tokenFields.length; j++) {
					keywords.push(tokenFields[j].token);
				}
			}
			return keywords;
		},
		formatAccuracy: function(accuracyValue) {
			var accuracy = accuracyValue;
			if (accuracy <= 0) {
				return;
			}
			var accuracyPercentage = Math.round(accuracy * 100);
			return accuracyPercentage + "%";
		},
		onPressClassifyButton: function(oEvent) {
			var response;
			var that = this;
			var data = {
				business_object: "ticket",
				messages: [{
					id: 1001,
					contents: [{
						"field": "text",
						"value": that.getView().byId("InputText").getValue()
					}]
				}],
				options: {
					classification_keyword: true
				}
			};
			var url = "https://ml-test.apimanagement.hana.ondemand.com/sti/standalone/text/classify";
			$.ajax({
				type: "POST",
				url: url,
				headers: {
					"Authorization": "Bearer " + oStorage.get("/AccessToken"),
					"Content-Type": "application/json"
				},
				data: JSON.stringify(data),
				success: function(result, textStatus, jqXHR) {
					response = result;
					if (response.results && response.results[0].status === 0) {
						that.getView().getModel().setProperty("/OutputLabel", response.results[0].classification[0].field);
						that.getView().getModel().setProperty("/OutputResult", response.results[0].classification[0].value);
						that.getView().getModel().setProperty("/ClassifyConfidence", that.formatAccuracy(response.results[0].classification[0].confidence));
						var keywordsResponse = response.results[0].keyword;
						that.getView().getModel().setProperty("/keyWords", that.getKeywordsUsed(keywordsResponse));
						that.getView().getModel().setProperty("/detectedLanguage", response.results[0].detected_language);
					} else if (response.results[0].status === 91) {
						alert("Error occured, please refresh the application");
					}
				},
				error: function(jqXHR, textStatus, error) {
						alert("Error occured, please refresh the application");
				}
			});
		}
	});
});